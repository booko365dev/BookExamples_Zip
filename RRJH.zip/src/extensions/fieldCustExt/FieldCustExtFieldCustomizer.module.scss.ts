/* tslint:disable */
require("./FieldCustExtFieldCustomizer.module.css");
const styles = {
  FieldCustExt: 'FieldCustExt_cec4ed9b',
  cell: 'cell_cec4ed9b',
};

export default styles;
/* tslint:enable */