define([], function() {
  return {
    "Title": "FieldCustExtFieldCustomizer"
  }
});