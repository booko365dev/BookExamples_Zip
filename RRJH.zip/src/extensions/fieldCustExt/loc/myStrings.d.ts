declare interface IFieldCustExtFieldCustomizerStrings {
  Title: string;
}

declare module 'FieldCustExtFieldCustomizerStrings' {
  const strings: IFieldCustExtFieldCustomizerStrings;
  export = strings;
}
