//gavdcodebegin 06
export interface IListItem {  
    Title?: string;  
    Id: number;  
}
//gavdcodeend 06