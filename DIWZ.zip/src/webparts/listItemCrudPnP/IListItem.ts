//gavdcodebegin 23
export interface IListItem {  
    Title?: string;  
    Id: number;  
}
//gavdcodeend 23