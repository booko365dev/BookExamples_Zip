/* tslint:disable */
require("./ListItemCrudPnPWebPart.module.css");
const styles = {
  listItemCrudPnP: 'listItemCrudPnP_f6ef1b07',
  container: 'container_f6ef1b07',
  row: 'row_f6ef1b07',
  column: 'column_f6ef1b07',
  'ms-Grid': 'ms-Grid_f6ef1b07',
  title: 'title_f6ef1b07',
  subTitle: 'subTitle_f6ef1b07',
  description: 'description_f6ef1b07',
  button: 'button_f6ef1b07',
  label: 'label_f6ef1b07'
};

export default styles;
/* tslint:enable */