declare interface IExternalLibrariesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ExternalLibrariesWebPartStrings' {
  const strings: IExternalLibrariesWebPartStrings;
  export = strings;
}
