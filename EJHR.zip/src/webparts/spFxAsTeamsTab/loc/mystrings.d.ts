declare interface ISpFxAsTeamsTabWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpFxAsTeamsTabWebPartStrings' {
  const strings: ISpFxAsTeamsTabWebPartStrings;
  export = strings;
}
