/* tslint:disable */
require("./SpFxAsTeamsTabWebPart.module.css");
const styles = {
  spFxAsTeamsTab: 'spFxAsTeamsTab_13932223',
  container: 'container_13932223',
  row: 'row_13932223',
  column: 'column_13932223',
  'ms-Grid': 'ms-Grid_13932223',
  title: 'title_13932223',
  subTitle: 'subTitle_13932223',
  description: 'description_13932223',
  button: 'button_13932223',
  label: 'label_13932223'
};

export default styles;
/* tslint:enable */