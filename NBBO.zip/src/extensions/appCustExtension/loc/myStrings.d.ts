declare interface IAppCustExtensionApplicationCustomizerStrings {
  Title: string;
}

declare module 'AppCustExtensionApplicationCustomizerStrings' {
  const strings: IAppCustExtensionApplicationCustomizerStrings;
  export = strings;
}
