/* tslint:disable */
require("./OtherPnPjsWebPart.module.css");
const styles = {
  otherPnPjs: 'otherPnPjs_c9302f98',
  container: 'container_c9302f98',
  row: 'row_c9302f98',
  column: 'column_c9302f98',
  'ms-Grid': 'ms-Grid_c9302f98',
  title: 'title_c9302f98',
  subTitle: 'subTitle_c9302f98',
  description: 'description_c9302f98',
  button: 'button_c9302f98',
  label: 'label_c9302f98'
};

export default styles;
/* tslint:enable */