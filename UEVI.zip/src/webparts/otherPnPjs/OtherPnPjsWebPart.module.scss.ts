
require("./OtherPnPjsWebPart.module.css");
const styles = {
  otherPnPjs: 'otherPnPjs_c1ad2af0',
  teams: 'teams_c1ad2af0',
  welcome: 'welcome_c1ad2af0',
  welcomeImage: 'welcomeImage_c1ad2af0',
  links: 'links_c1ad2af0'
};

export default styles;
