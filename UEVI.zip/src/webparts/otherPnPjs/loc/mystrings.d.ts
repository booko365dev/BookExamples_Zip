declare interface IOtherPnPjsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'OtherPnPjsWebPartStrings' {
  const strings: IOtherPnPjsWebPartStrings;
  export = strings;
}
