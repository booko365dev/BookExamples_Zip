
require("./GetMeGraph01WebPart.module.css");
const styles = {
  getMeGraph01: 'getMeGraph01_294c9561',
  teams: 'teams_294c9561',
  welcome: 'welcome_294c9561',
  welcomeImage: 'welcomeImage_294c9561',
  links: 'links_294c9561'
};

export default styles;
