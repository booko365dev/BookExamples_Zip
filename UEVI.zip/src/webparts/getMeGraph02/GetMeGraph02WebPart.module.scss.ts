
require("./GetMeGraph02WebPart.module.css");
const styles = {
  getMeGraph02: 'getMeGraph02_e6ef1239',
  teams: 'teams_e6ef1239',
  welcome: 'welcome_e6ef1239',
  welcomeImage: 'welcomeImage_e6ef1239',
  links: 'links_e6ef1239'
};

export default styles;
