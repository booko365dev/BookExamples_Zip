//gavdcodebegin 006
export interface IListItem {  
    Title?: string;  
    Id: number;  
}
//gavdcodeend 006