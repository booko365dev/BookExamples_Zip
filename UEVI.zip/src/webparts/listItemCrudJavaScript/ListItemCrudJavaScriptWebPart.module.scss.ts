/* tslint:disable */
require("./ListItemCrudJavaScriptWebPart.module.css");
const styles = {
  listItemCrudJavaScript: 'listItemCrudJavaScript_ba6a0c5f',
  container: 'container_ba6a0c5f',
  row: 'row_ba6a0c5f',
  column: 'column_ba6a0c5f',
  'ms-Grid': 'ms-Grid_ba6a0c5f',
  title: 'title_ba6a0c5f',
  subTitle: 'subTitle_ba6a0c5f',
  description: 'description_ba6a0c5f',
  button: 'button_ba6a0c5f',
  label: 'label_ba6a0c5f'
};

export default styles;
/* tslint:enable */