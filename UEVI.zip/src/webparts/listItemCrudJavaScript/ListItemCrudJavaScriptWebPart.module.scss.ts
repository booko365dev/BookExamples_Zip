
require("./ListItemCrudJavaScriptWebPart.module.css");
const styles = {
  listItemCrudJavaScript: 'listItemCrudJavaScript_3dd579a8',
  teams: 'teams_3dd579a8',
  welcome: 'welcome_3dd579a8',
  welcomeImage: 'welcomeImage_3dd579a8',
  links: 'links_3dd579a8'
};

export default styles;
