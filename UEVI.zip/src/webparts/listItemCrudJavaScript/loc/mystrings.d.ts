declare interface IListItemCrudJavaScriptWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ListItemCrudJavaScriptWebPartStrings' {
  const strings: IListItemCrudJavaScriptWebPartStrings;
  export = strings;
}
