/* tslint:disable */
require("./ExternalLibrariesWebPart.module.css");
const styles = {
  externalLibraries: 'externalLibraries_d614e5b1',
  container: 'container_d614e5b1',
  row: 'row_d614e5b1',
  column: 'column_d614e5b1',
  'ms-Grid': 'ms-Grid_d614e5b1',
  title: 'title_d614e5b1',
  subTitle: 'subTitle_d614e5b1',
  description: 'description_d614e5b1',
  button: 'button_d614e5b1',
  label: 'label_d614e5b1'
};

export default styles;
/* tslint:enable */