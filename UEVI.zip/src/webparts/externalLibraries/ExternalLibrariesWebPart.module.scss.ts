
require("./ExternalLibrariesWebPart.module.css");
const styles = {
  externalLibraries: 'externalLibraries_23d1cd81',
  teams: 'teams_23d1cd81',
  welcome: 'welcome_23d1cd81',
  welcomeImage: 'welcomeImage_23d1cd81',
  links: 'links_23d1cd81'
};

export default styles;
