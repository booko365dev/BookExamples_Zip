
require("./HelloWorldWebPart.module.css");
const styles = {
  helloWorld: 'helloWorld_547bc1b9',
  teams: 'teams_547bc1b9',
  welcome: 'welcome_547bc1b9',
  welcomeImage: 'welcomeImage_547bc1b9',
  links: 'links_547bc1b9'
};

export default styles;
