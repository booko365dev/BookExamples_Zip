declare interface IListItemCrudPnPWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ListItemCrudPnPWebPartStrings' {
  const strings: IListItemCrudPnPWebPartStrings;
  export = strings;
}
