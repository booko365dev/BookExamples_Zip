
require("./ListItemCrudPnPWebPart.module.css");
const styles = {
  listItemCrudPnP: 'listItemCrudPnP_25aa227b',
  teams: 'teams_25aa227b',
  welcome: 'welcome_25aa227b',
  welcomeImage: 'welcomeImage_25aa227b',
  links: 'links_25aa227b'
};

export default styles;
