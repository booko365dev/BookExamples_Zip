declare interface IFieldCustExtensionFieldCustomizerStrings {
  Title: string;
}

declare module 'FieldCustExtensionFieldCustomizerStrings' {
  const strings: IFieldCustExtensionFieldCustomizerStrings;
  export = strings;
}
