define([], function() {
  return {
    "Title": "FieldCustExtensionFieldCustomizer"
  }
});