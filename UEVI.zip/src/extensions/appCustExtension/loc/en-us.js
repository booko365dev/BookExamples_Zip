define([], function() {
  return {
    "Title": "AppCustExtensionApplicationCustomizer"
  }
});