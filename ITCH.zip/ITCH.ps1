﻿
#gavdcodebegin 01
Function ConnectPsExoV2()
{
    Connect-ExchangeOnline -UserPrincipalName $configFile.appsettings.UserName
}
#gavdcodeend 01

#-----------------------------------------------------------------------------------------

#gavdcodebegin 02
Function ExPsExoV2GetMailboxesByPropertySet()
{
    Get-EXOMailbox -PropertySets Minimum,Policy
}
#gavdcodeend 02

#gavdcodebegin 03
Function ExPsExoV2GetMailboxesByProperty()
{
    Get-EXOMailbox -Properties UserPrincipalName,Alias
}
#gavdcodeend 03

#gavdcodebegin 04
Function ExPsExoV2GetMailboxesBySetAndProperty()
{
    Get-EXOMailbox -PropertySets Hold,Moderation -Properties UserPrincipalName,Alias
}
#gavdcodeend 04

#gavdcodebegin 05
Function ExPsExoV2GetClientAccessSettings()
{
    Get-EXOCASMailbox -Identity $configFile.appsettings.UserName
}
#gavdcodeend 05

#gavdcodebegin 06
Function ExPsExoV2GetEmailboxPermissions()
{
    Get-EXOMailboxPermission -Identity $configFile.appsettings.UserName
}
#gavdcodeend 06

#gavdcodebegin 07
Function ExPsExoV2GetEmailboxStatistics()
{
    Get-EXOMailboxStatistics -Identity $configFile.appsettings.UserName
}
#gavdcodeend 07

#gavdcodebegin 08
Function ExPsExoV2GetFolderPermissions()
{
    $myIdentifier = $configFile.appsettings.UserName + ":\Inbox"
    Get-EXOMailboxFolderPermission -Identity $myIdentifier
}
#gavdcodeend 08

#gavdcodebegin 09
Function ExPsExoV2GetFolderStatisticsAll()
{
    Get-EXOMailboxFolderStatistics -Identity $configFile.appsettings.UserName
}
#gavdcodeend 09

#gavdcodebegin 10
Function ExPsExoV2GetFolderStatisticsOne()
{
    Get-EXOMailboxFolderStatistics -Identity $configFile.appsettings.UserName `
                                                            -FolderScope Calendar
}
#gavdcodeend 10

#gavdcodebegin 11
Function ExPsExoV2GetDeviceStatistics()
{
    Get-EXOMobileDeviceStatistics -Mailbox $configFile.appsettings.UserName
}
#gavdcodeend 11

#gavdcodebegin 12
Function ExPsExoV2GetRecipients()
{
    Get-EXORecipient -Identity $configFile.appsettings.UserName
}
#gavdcodeend 12

#gavdcodebegin 13
Function ExPsExoV2GetRecipientPermissions()
{
    Get-EXORecipientPermission -ResultSize 5
}
#gavdcodeend 13

#-----------------------------------------------------------------------------------------

[xml]$configFile = get-content "C:\Projects\ConfigValuesPS.config"

ConnectPsExoV2

#ExPsExoV2GetMailboxesByPropertySet
#ExPsExoV2GetMailboxesByProperty
#ExPsExoV2GetMailboxesBySetAndProperty
#ExPsExoV2GetClientAccessSettings
#ExPsExoV2GetEmailboxPermissions
#ExPsExoV2GetEmailboxStatistics
#ExPsExoV2GetFolderPermissions
#ExPsExoV2GetFolderStatisticsAll
#ExPsExoV2GetFolderStatisticsOne
#ExPsExoV2GetDeviceStatistics
#ExPsExoV2GetRecipients
#ExPsExoV2GetRecipientPermissions

Disconnect-ExchangeOnline -Confirm:$false

Write-Host "Done"  

