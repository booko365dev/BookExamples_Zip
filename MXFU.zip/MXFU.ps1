﻿##---------------------------------------------------------------------------------------
## ------**** ATTENTION **** This is a PowerShell solution ****--------------------------
##---------------------------------------------------------------------------------------

##---------------------------------------------------------------------------------------
##***-----------------------------------*** Login routines ***---------------------------
##---------------------------------------------------------------------------------------

Function PsGraphRestApi_GetAzureTokenApplication
{
	Param(
		[Parameter(Mandatory=$True)]
		[String]$ClientID,
 
		[Parameter(Mandatory=$True)]
		[String]$ClientSecret,
 
		[Parameter(Mandatory=$False)]
		[String]$TenantName
	)
   
	 $LoginUrl = "https://login.microsoftonline.com"
	 $ScopeUrl = "https://graph.microsoft.com/.default"
	 
	 $myBody  = @{ Scope = $ScopeUrl; `
					grant_type = "client_credentials"; `
					client_id = $ClientID; `
					client_secret = $ClientSecret }

	 $accessToken = Invoke-RestMethod `
					-Method Post `
					-Uri $LoginUrl/$TenantName/oauth2/v2.0/token `
					-Body $myBody

	return $accessToken
}

Function PsGraphRestApi_GetAzureTokenDelegation
{
	Param(
		[Parameter(Mandatory=$True)]
		[String]$ClientID,
 
		[Parameter(Mandatory=$True)]
		[String]$TenantName,
 
		[Parameter(Mandatory=$True)]
		[String]$UserName,
 
		[Parameter(Mandatory=$True)]
		[String]$UserPw
	)

	 $LoginUrl = "https://login.microsoftonline.com"
	 $ScopeUrl = "https://graph.microsoft.com/.default"

	 $myBody  = @{ Scope = $ScopeUrl; `
					grant_type = "Password"; `
					client_id = $ClientID; `
					Username = $UserName; `
					Password = $UserPw }

	 $accessToken = Invoke-RestMethod `
					-Method Post `
					-Uri $LoginUrl/$TenantName/oauth2/v2.0/token `
					-Body $myBody

	return $accessToken
}


##---------------------------------------------------------------------------------------
##***-----------------------------------*** Example routines ***-------------------------
##---------------------------------------------------------------------------------------


#gavdcodebegin 001
Function PsGraphRestApiExcel_GetSpreadsheetId
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
											$itemId + "/driveitem/workbook/worksheets"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	Write-Host "Name- " $xlsxObject.value[0].name " > SheetID- " $xlsxObject.value[0].id
}
#gavdcodeend 001 

#gavdcodebegin 002
Function PsGraphRestApiExcel_GetDriveId
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$tenantBaseUrl = "[tenant].sharepoint.com"
	$siteCollName = "Chapter03"

	# Get the Drive ID
	$Url = $graphBaseUrl + "/sites/" + $tenantBaseUrl + `
											":/sites/" + $siteCollName + ":/drives"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	Write-Host "Name - " $xlsxObject.value[0].name " > Drive ID - `
															" $xlsxObject.value[0].id
}
#gavdcodeend 002 

#gavdcodebegin 003
Function PsGraphRestApiExcel_GetSpreadsheetByDriveId
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$tenantBaseUrl = "[tenant].sharepoint.com"
	$driveId = "b!0br1f8VWqEWObdlRrScqOvjdCbTLvTFDuDobRNveAdAa5_SrQGIvSqk_ezm-VTvq"

	# Get the Document ID
	$Url = $graphBaseUrl + "/sites/" + $tenantBaseUrl + "/drives/" + $driveId `
																	+ "/root/children"  
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	Write-Host "Name- " $xlsxObject.value[0].name " > DocumentID- " `
															$xlsxObject.value[0].id
}
#gavdcodeend 003 

#gavdcodebegin 004
Function PsGraphRestApiExcel_GetSpreadsheetByDriveIdAndItemId
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$tenantBaseUrl = "[tenant].sharepoint.com"
	$driveId = "b!0br1f8VWqEWObdlRrScqOvjdCbTLvTFDuDobRNveAdAa5_SrQGIvSqk_ezm-VTvq"
	$itemId = "015XX4O2PIQCTK65N6QBDIFW2VWDDBPEIV"

	$Url = $graphBaseUrl + "/sites/" + $tenantBaseUrl + "/drives/" + $driveId + `
											"/items/" + $itemId + "/workbook/worksheets"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	Write-Host "Name- " $xlsxObject.value[0].name " > SheetID- " $xlsxObject.value[0].id
}
#gavdcodeend 004 

#gavdcodebegin 005
Function PsGraphRestApiExcel_GetSpreadsheetInOnedriveByName
{
	# App Registration type:		Delegated
	# App Registration permissions: Mail.ReadBasic, Mail.Read, Mail.ReadWrite

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$xlsxName = "TestBook.xlsx"

	$Url = $graphBaseUrl + "users/" + $cnfUserName + `
								"/drive/root:/" + $xlsxName + ":/workbook/worksheets"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	Write-Host "Name- " $xlsxObject.value[0].name " > SheetID- " $xlsxObject.value[0].id
}
#gavdcodeend 005 

#gavdcodebegin 006
Function PsGraphRestApiExcel_GetSpreadsheetInOnedriveById
{
	# App Registration type:		Delegated
	# App Registration permissions: Mail.ReadBasic, Mail.Read, Mail.ReadWrite

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$itemId = "01Y5GMQHD7LKQV6L5URRC32IH5XNQN34WP"

	# To find the spreadsheet ID ($itemId)
	#$Url = $graphBaseUrl + "users/" + $configFile.appsettings.UserName + `
	#														"/drive/root/children/"		

	$Url = $graphBaseUrl + "users/" + $configFile.appsettings.UserName + `
									"/drive/items/" + $itemId + "/workbook/worksheets"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	Write-Host "Name- " $xlsxObject.value[0].name " > SheetID- " $xlsxObject.value[0].id
}
#gavdcodeend 006 

#gavdcodebegin 007
Function PsGraphRestApiExcel_GetSpreadsheetInOnedriveByMe
{
	# App Registration type:		Delegate
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$xlsxName = "TestBook.xlsx"

	$Url = $graphBaseUrl + "me/drive/root:/" + $xlsxName + ":/workbook/worksheets"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url

	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	Write-Host "Name- " $xlsxObject.value[0].name " > SheetID- " $xlsxObject.value[0].id
}
#gavdcodeend 007 

#gavdcodebegin 008
Function PsGraphRestApiExcel_GetAllWorksheets
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
											$itemId + "/driveitem/workbook/worksheets"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	foreach($oneValue in $xlsxObject.value) {
		Write-Host "Name- " $oneValue.name " >> SheetID- " $oneValue.id
	}
}
#gavdcodeend 008 

#gavdcodebegin 009
Function PsGraphRestApiExcel_GetOneWorksheetByName
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + $worksheetName
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 009 

#gavdcodebegin 010
Function PsGraphRestApiExcel_CreateWorksheet
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
											$itemId + "/driveitem/workbook/worksheets"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'name': 'PowerShellSheet' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 010 

#gavdcodebegin 011
Function PsGraphRestApiExcel_UpdateWorksheet
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + $worksheetName

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'name': 'PsSheetUpdated', 'position': 1 }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Patch `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 011 

#gavdcodebegin 012
Function PsGraphRestApiExcel_DeleteWorksheet
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheetUpdated"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + $worksheetName

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Delete
}
#gavdcodeend 012 

#gavdcodebegin 013
Function PsGraphRestApiExcel_CallFunction
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
										$itemId + "/driveitem/workbook/functions/arabic"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'text' : 'MLVI' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 013 

#gavdcodebegin 014
Function PsGraphRestApiExcel_GetAllComments
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
											$itemId + "/driveitem/workbook/comments"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	foreach($oneValue in $xlsxObject.value) {
		Write-Host "Name- " $oneValue.name " > SheetID- " $oneValue.id
	}
}
#gavdcodeend 014 

#gavdcodebegin 015
Function PsGraphRestApiExcel_GetAllReplaysOneComment
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$commentId = "{BC2DBDF6-F028-4B56-A87A-C322B9BCA5B4}"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
					$itemId + "/driveitem/workbook/comments/" + $commentId + "/replies"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult

	$xlsxObject = ConvertFrom-Json –InputObject $myResult
	foreach($oneValue in $xlsxObject.value) {
		Write-Host "Name- " $oneValue.name " > SheetID- " $oneValue.id
	}
}
#gavdcodeend 015 

#gavdcodebegin 016
Function GrPsCreateReply
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "b955bdba-9761-4119-917f-6bcc7c449a5a"  # Site Collection ID
	$listId = "67ba9db9-c048-45fe-b790-75ad32335010"
	$itemId = "1"
	$commentId = "{11075FE6-6B52-4B18-8E4B-A4387CECBDD5}"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
					$itemId + "/driveitem/workbook/comments/" + $commentId + "/replies"

	$accessToken = PsGraphRestApi_GetAzureTokenApplication `
								-ClientID $cnfClientIDApp `
								-ClientSecret $cnfClientSecretApp `
								-TenantName $cnfTenantName
	
	$myBody = "{ 'content': 'Reply from PowerShell',
				 'contentType': 'plain' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 016 

#gavdcodebegin 017
Function PsGraphRestApiExcel_InsertRange
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/range(address='B2:C3')/insert"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'shift': 'Right' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 017 

#gavdcodebegin 018
Function PsGraphRestApiExcel_GetRange
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/range(address='B2:E7')"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 018 

#gavdcodebegin 019
Function PsGraphRestApiExcel_UpdateRange
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/range(address='A1:B2')"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'values' : [['Excel', '456'],['1/1/2021', null]],
				 'formulas' : [[null, null], [null, '=B1*5']],
				 'numberFormat' : [[null,null], ['m-ddd', null]] }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Patch `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 019 

#gavdcodebegin 020
Function PsGraphRestApiExcel_ClearRange
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/range(address='B2:C3')/clear"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'applyTo': 'All' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 020 

#gavdcodebegin 021
Function PsGraphRestApiExcel_DeleteRange
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/range(address='B2:C3')/delete"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'applyTo': 'All' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 021 

#gavdcodebegin 022
Function PsGraphRestApiExcel_CreateNamedRange
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/names/add"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'name': 'GraphNamedRange',
			     'reference': '=B2:C3',
			     'comment': 'Named range set by Graph' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 022 

#gavdcodebegin 023
Function PsGraphRestApiExcel_GetAllNamedRanges
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/names"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 023 

#gavdcodebegin 024
Function PsGraphRestApiExcel_GetOneNamedRange
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$namedRange = "GraphNamedRange"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/names/" + $namedRange
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 024 

#gavdcodebegin 025
Function PsGraphRestApiExcel_UpdateNamedRange
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$namedRange = "GraphNamedRange"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/names/" + $namedRange

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'comment': 'Named Range Updated' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Patch `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 025 

#gavdcodebegin 026
Function PsGraphRestApiExcel_CreateTable
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/add"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'address': 'F5:I9',
			     'hasHeaders': true }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 026 

#gavdcodebegin 027
Function PsGraphRestApiExcel_GetAllTables
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 027 

#gavdcodebegin 028
Function PsGraphRestApiExcel_UpdateTable
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "Table1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + $tableName

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'name': 'GraphTable', 
				 'showTotals': false, 
				 'style': 'TableStyleMedium3' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Patch `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 028 

#gavdcodebegin 029
Function PsGraphRestApiExcel_GetTableRows
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + $tableName + "/rows"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 029 

#gavdcodebegin 030
Function PsGraphRestApiExcel_GetTableColumns
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + $tableName + "/columns"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 030 

#gavdcodebegin 031
Function PsGraphRestApiExcel_GetTableOneColumn
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"
	$columnIndex = "3"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + `
							$tableName + "/columns/" + $columnIndex
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 031 

#gavdcodebegin 032
Function PsGraphRestApiExcel_CreateTableRow
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"
	$rowIndex = 2

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + $tableName + "/rows/add"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'values': [ [11, 'ab', 22, 'cd'] ],
			     'index': " + $rowIndex + " }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 032 

#gavdcodebegin 033
Function PsGraphRestApiExcel_CreateTableColumn
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"
	$columnIndex = 2

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + $tableName + "/columns/add"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'values': [ ['myCol'], [11], ['ab'], [22], ['cd'], [33] ],
			     'index': " + $columnIndex + " }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
											-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 033 

#gavdcodebegin 034
Function PsGraphRestApiExcel_DeleteColumn
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"
	$columnIndex = 3

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + `
							$tableName + "/columns/" + $columnIndex

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Delete

	Write-Host $myResult
}
#gavdcodeend 034 

#gavdcodebegin 035
Function PsGraphRestApiExcel_TableSort
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"
	$columnIndex = 2

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + $tableName + "/sort/apply"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'fields' : [
				  { 'key': 0,
				   'ascending': true
				  }
				] }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 035 

#gavdcodebegin 036
Function PsGraphRestApiExcel_TableFilter
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"
	$columnIndex = 1

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + `
							$tableName + "/columns/" + $columnIndex + "/filter/apply"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'criteria' : 
				  { 'filterOn': 'custom',
				    'criterion1': '>1',
				    'operator': 'and',
				    'criterion2': '<8'
				  } }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 036 

#gavdcodebegin 037
Function PsGraphRestApiExcel_TableClearFilter
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$tableName = "GraphTable"
	$columnIndex = 1

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/tables/" + `
							$tableName + "/columns/" + $columnIndex + "/filter/clear"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 037 

#gavdcodebegin 038
Function PsGraphRestApiExcel_CreateChart
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/charts/add"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'type': 'ColumnStacked',
				 'sourceData': 'F5:G7',
				 'seriesBy': 'Auto' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 038 

#gavdcodebegin 039
Function PsGraphRestApiExcel_GetAllCharts
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/charts"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 039 

#gavdcodebegin 040
Function PsGraphRestApiExcel_GetAllChartsGetChartImage
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$chartName = "Chart 1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/charts/" + $chartName + `
							"/Image(width=0,height=0,fittingMode='fit')"
	
	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url
	
	Write-Host $myResult
}
#gavdcodeend 040 

#gavdcodebegin 041
Function PsGraphRestApiExcel_UpdateChartSource
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$chartName = "Chart 1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/charts/" + $chartName + "/setData"

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'type': 'ColumnStacked',
				 'sourceData': 'F5:G8',
				 'seriesBy': 'Auto' }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Post `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 041 

#gavdcodebegin 042
Function PsGraphRestApiExcel_UpdateChartProperties
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$chartName = "Chart 1"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/charts/" + $chartName

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myBody = "{ 'name': 'ChartGraph', 
				 'top': 10, 'left': 10, 
				 'height': 200.0, 'width': 300.0 }"
	$myContentType = "application/json"
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Patch `
												-Body $myBody -ContentType $myContentType

	Write-Host $myResult
}
#gavdcodeend 042 

#gavdcodebegin 043
Function PsGraphRestApiExcel_DeleteChart
{
	# App Registration type:		Delegated
	# App Registration permissions: Sites.ReadWrite.All, Files.ReadWrite.All

	$graphBaseUrl = "https://graph.microsoft.com/v1.0/"
	$siteId = "7ff5bad1-56c5-45a8-8e6d-d951ad272a3a"  # Site Collection ID
	$listId = "ad7b2787-1494-4940-9692-a0080a105af0"
	$itemId = "1"
	$worksheetName = "PsSheet"
	$chartName = "ChartGraph"

	$Url = $graphBaseUrl + "sites/" + $siteId + "/lists/" + $listId + "/items/" + `
							$itemId + "/driveitem/workbook/worksheets/" + `
							$worksheetName + "/charts/" + $chartName

	$accessToken = PsGraphRestApi_GetAzureTokenDelegation `
								-ClientID $cnfClientIdWithAccPw `
								-TenantName $cnfTenantName `
								-UserName $cnfUserName `
								-UserPw $cnfUserPw
	
	$myHeader = @{ 'Authorization' = "$($accessToken.token_type) $($accessToken.access_token)" }
	
	$myResult = Invoke-WebRequest -Headers $myHeader -Uri $Url -Method Delete
}
#gavdcodeend 043 


##---------------------------------------------------------------------------------------
##***-----------------------------------*** Running the routines ***---------------------
##---------------------------------------------------------------------------------------

# *** Latest Source Code Index: 043 ***
#region ConfigValuesCS.config
[xml]$config = Get-Content -Path "C:\Projects\ConfigValuesCS.config"
$cnfUserName               = $config.SelectSingleNode("//add[@key='UserName']").value
$cnfUserPw                 = $config.SelectSingleNode("//add[@key='UserPw']").value
$cnfTenantUrl              = $config.SelectSingleNode("//add[@key='TenantUrl']").value     # https://domain.onmicrosoft.com
$cnfSiteBaseUrl            = $config.SelectSingleNode("//add[@key='SiteBaseUrl']").value   # https://domain.sharepoint.com
$cnfSiteAdminUrl           = $config.SelectSingleNode("//add[@key='SiteAdminUrl']").value  # https://domain-admin.sharepoint.com
$cnfSiteCollUrl            = $config.SelectSingleNode("//add[@key='SiteCollUrl']").value   # https://domain.sharepoint.com/sites/TestSite
$cnfTenantName             = $config.SelectSingleNode("//add[@key='TenantName']").value
$cnfClientIdWithAccPw      = $config.SelectSingleNode("//add[@key='ClientIdWithAccPw']").value
$cnfClientIdWithSecret     = $config.SelectSingleNode("//add[@key='ClientIdWithSecret']").value
$cnfClientSecret           = $config.SelectSingleNode("//add[@key='ClientSecret']").value
$cnfClientIdWithCert       = $config.SelectSingleNode("//add[@key='ClientIdWithCert']").value
$cnfCertificateThumbprint  = $config.SelectSingleNode("//add[@key='CertificateThumbprint']").value
$cnfCertificateFilePath    = $config.SelectSingleNode("//add[@key='CertificateFilePath']").value
$cnfCertificateFilePw      = $config.SelectSingleNode("//add[@key='CertificateFilePw']").value
#endregion ConfigValuesCS.config

#PsGraphRestApiExcel_GetSpreadsheetId
#PsGraphRestApiExcel_GetDriveId
#PsGraphRestApiExcel_GetSpreadsheetByDriveId
#PsGraphRestApiExcel_GetSpreadsheetByDriveIdAndItemId
#PsGraphRestApiExcel_GetSpreadsheetInOnedriveByName
#PsGraphRestApiExcel_GetSpreadsheetInOnedriveById
#PsGraphRestApiExcel_GetSpreadsheetInOnedriveByMe
#PsGraphRestApiExcel_GetAllWorksheets
#PsGraphRestApiExcel_GetOneWorksheetByName
#PsGraphRestApiExcel_CreateWorksheet
#PsGraphRestApiExcel_UpdateWorksheet
#PsGraphRestApiExcel_DeleteWorksheet
#PsGraphRestApiExcel_CallFunction
#PsGraphRestApiExcel_GetAllComments
#PsGraphRestApiExcel_GetAllReplaysOneComment
#GrPsCreateReply ==> Not used in book
#PsGraphRestApiExcel_InsertRange
#PsGraphRestApiExcel_GetRange
#PsGraphRestApiExcel_UpdateRange
#PsGraphRestApiExcel_ClearRange
#PsGraphRestApiExcel_DeleteRange
#PsGraphRestApiExcel_CreateNamedRange
#PsGraphRestApiExcel_GetAllNamedRanges
#PsGraphRestApiExcel_GetOneNamedRange
#PsGraphRestApiExcel_UpdateNamedRange
#PsGraphRestApiExcel_CreateTable
#PsGraphRestApiExcel_GetAllTables
#PsGraphRestApiExcel_UpdateTable
#PsGraphRestApiExcel_GetTableRows
#PsGraphRestApiExcel_GetTableColumns
#PsGraphRestApiExcel_GetTableOneColumn
#PsGraphRestApiExcel_CreateTableRow
#PsGraphRestApiExcel_CreateTableColumn
#PsGraphRestApiExcel_DeleteColumn
#PsGraphRestApiExcel_TableSort
#PsGraphRestApiExcel_TableFilter
#PsGraphRestApiExcel_TableClearFilter
#PsGraphRestApiExcel_CreateChart
#PsGraphRestApiExcel_GetAllCharts
#PsGraphRestApiExcel_GetAllChartsGetChartImage
#PsGraphRestApiExcel_UpdateChartSource
#PsGraphRestApiExcel_UpdateChartProperties
#PsGraphRestApiExcel_DeleteChart

Write-Host "Done" 
